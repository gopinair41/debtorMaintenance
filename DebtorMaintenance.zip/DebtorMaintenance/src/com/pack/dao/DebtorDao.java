package com.pack.dao;
import java.sql.*;

import com.pack.model.Debtor;



public class DebtorDao {
	
	public   int save(Debtor u){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("insert into debtor(debtorName,Address,faxNo,mobNo,emailId,bankName,Branch,bAddress,accountNo,Currency,Date)  values(?,?,?,?,?,?,?,?,?,?,SYSDATE())");
		 
			System.out.println(u.getDebtorName());
			//ps.setInt(1,u.getD_id());
		 	ps.setString(1,u.getDebtorName());
			ps.setString(2,u.getAddress());
			ps.setLong(3,u.getFaxNo());
			ps.setLong(4,u.getMobNo());
		 	ps.setString(5,u.getEmailId());
			ps.setString(6,u.getBankName());
			ps.setString(7,u.getBranch());
			ps.setString(8,u.getbAddress());
		 	ps.setLong(9,u.getAccountNo());
			ps.setString(10,u.getCurrency());
			
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;
		
		
	}

}
