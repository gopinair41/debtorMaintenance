package com.pack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.pack.dao.MySqlConn;

public class AuthorizeDao {
	public void authorize(int id) throws SQLException{
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("update debtor set Status=? where d_id=?");
		ps.setString(1,"A");
		ps.setInt(2,id);
		
	 	ps.executeUpdate();
	}
	/*public void reject(int id) throws SQLException{
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("update debtor set Status=? where d_id=?");
		ps.setString(1,"R");
		ps.setInt(2,id);
		ps.executeUpdate();
		
		
	 	

}
	public void reject(int id, String Reason) {
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("insert into debtor(Reason) values(?) where d_id=?");
		ps.setInt(2,id);
		ps.setString(1,getReason());
		ps.executeUpdate();
		
		
	}*/
	public void reject(int id, String rs) throws SQLException{
		// TODO Auto-generated method stub
		Connection con=MySqlConn.getCon();
		PreparedStatement ps=con.prepareStatement("update debtor set Status=? where d_id=?");
		PreparedStatement ps1=con.prepareStatement("update debtor set Reason=? where d_id=?");
		ps.setString(1,"R");
		ps.setInt(2,id);
		ps1.setInt(2,id);
		ps1.setString(1,rs);
		ps.executeUpdate();
		ps1.executeUpdate();
		
	}
}
