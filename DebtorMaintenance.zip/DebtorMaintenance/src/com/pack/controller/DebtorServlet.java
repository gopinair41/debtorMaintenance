package com.pack.controller;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.dao.DebtorDao;

import com.pack.model.Debtor;

/**
 * Servlet implementation class DebtorServlet
 */
@WebServlet("/DebtorServlet")
public class DebtorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	DebtorDao debDao=new DebtorDao();
    public DebtorServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action=request.getParameter("action");
		//System.out.println(action);
		//String tid=UUID.randomUUID().toString();
		//request.setAttribute("txnid", tid);
		switch(action)
		{
		case "Add":
			insert(request,response);
		    break;
		
		}
		 
	
		
	}
	
	protected void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Debtor debt=new Debtor();
			
		
		debt.setDebtorName(request.getParameter("debtorName"));
		debt.setAddress(request.getParameter("Address"));
		debt.setFaxNo(Long.parseLong(request.getParameter("faxNo")));
		debt.setMobNo(Long.parseLong(request.getParameter("mobNo")));
		debt.setEmailId(request.getParameter("emailId"));
		debt.setBankName(request.getParameter("bankName"));
		debt.setBranch(request.getParameter("Branch"));
		debt.setbAddress(request.getParameter("bAddress"));
		debt.setAccountNo(Long.parseLong(request.getParameter("accountNo")));
		debt.setCurrency(request.getParameter("Currency"));
				 
		int i=debDao.save(debt);
		if(i>0){
		response.sendRedirect("review.jsp");
	}  
		   else{ response.sendRedirect("error.jsp");
		 
		}
		}
	
	


}
